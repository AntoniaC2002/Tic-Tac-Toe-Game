﻿
namespace Proiect_PCLP
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optiuniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jocNouToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iesireToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructiuniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.C3 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.C1 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.A1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.egaluri = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.o_castiga = new System.Windows.Forms.Label();
            this.x_castiga = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.player_x = new System.Windows.Forms.TextBox();
            this.player_o = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optiuniToolStripMenuItem,
            this.instructiuniToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(1190, 37);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optiuniToolStripMenuItem
            // 
            this.optiuniToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jocNouToolStripMenuItem,
            this.iesireToolStripMenuItem});
            this.optiuniToolStripMenuItem.Name = "optiuniToolStripMenuItem";
            this.optiuniToolStripMenuItem.Size = new System.Drawing.Size(87, 29);
            this.optiuniToolStripMenuItem.Text = "Optiuni";
            // 
            // jocNouToolStripMenuItem
            // 
            this.jocNouToolStripMenuItem.Name = "jocNouToolStripMenuItem";
            this.jocNouToolStripMenuItem.Size = new System.Drawing.Size(175, 34);
            this.jocNouToolStripMenuItem.Text = "Joc nou";
            this.jocNouToolStripMenuItem.Click += new System.EventHandler(this.jocNouToolStripMenuItem_Click);
            // 
            // iesireToolStripMenuItem
            // 
            this.iesireToolStripMenuItem.Name = "iesireToolStripMenuItem";
            this.iesireToolStripMenuItem.Size = new System.Drawing.Size(175, 34);
            this.iesireToolStripMenuItem.Text = "Iesire";
            this.iesireToolStripMenuItem.Click += new System.EventHandler(this.iesireToolStripMenuItem_Click);
            // 
            // instructiuniToolStripMenuItem
            // 
            this.instructiuniToolStripMenuItem.Name = "instructiuniToolStripMenuItem";
            this.instructiuniToolStripMenuItem.Size = new System.Drawing.Size(115, 29);
            this.instructiuniToolStripMenuItem.Text = "Instructiuni";
            this.instructiuniToolStripMenuItem.Click += new System.EventHandler(this.instructiuniToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.C3);
            this.panel1.Controls.Add(this.C2);
            this.panel1.Controls.Add(this.C1);
            this.panel1.Controls.Add(this.B3);
            this.panel1.Controls.Add(this.B2);
            this.panel1.Controls.Add(this.B1);
            this.panel1.Controls.Add(this.A3);
            this.panel1.Controls.Add(this.A2);
            this.panel1.Controls.Add(this.A1);
            this.panel1.Location = new System.Drawing.Point(18, 45);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(735, 618);
            this.panel1.TabIndex = 1;
            // 
            // C3
            // 
            this.C3.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.C3.Location = new System.Drawing.Point(486, 445);
            this.C3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(198, 164);
            this.C3.TabIndex = 8;
            this.C3.Tag = "8";
            this.C3.UseVisualStyleBackColor = true;
            this.C3.Click += new System.EventHandler(this.button_click);
            // 
            // C2
            // 
            this.C2.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.C2.Location = new System.Drawing.Point(259, 445);
            this.C2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(198, 164);
            this.C2.TabIndex = 7;
            this.C2.Tag = "7";
            this.C2.UseVisualStyleBackColor = true;
            this.C2.Click += new System.EventHandler(this.button_click);
            // 
            // C1
            // 
            this.C1.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.C1.Location = new System.Drawing.Point(28, 445);
            this.C1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(198, 164);
            this.C1.TabIndex = 6;
            this.C1.Tag = "6";
            this.C1.UseVisualStyleBackColor = true;
            this.C1.Click += new System.EventHandler(this.button_click);
            // 
            // B3
            // 
            this.B3.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.B3.Location = new System.Drawing.Point(486, 235);
            this.B3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(198, 164);
            this.B3.TabIndex = 5;
            this.B3.Tag = "5";
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.button_click);
            // 
            // B2
            // 
            this.B2.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.B2.Location = new System.Drawing.Point(259, 235);
            this.B2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(198, 164);
            this.B2.TabIndex = 4;
            this.B2.Tag = "4";
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.button_click);
            // 
            // B1
            // 
            this.B1.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.B1.Location = new System.Drawing.Point(28, 235);
            this.B1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(198, 164);
            this.B1.TabIndex = 3;
            this.B1.Tag = "3";
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.button_click);
            // 
            // A3
            // 
            this.A3.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.A3.Location = new System.Drawing.Point(486, 21);
            this.A3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(198, 164);
            this.A3.TabIndex = 2;
            this.A3.Tag = "2";
            this.A3.UseVisualStyleBackColor = true;
            this.A3.Click += new System.EventHandler(this.button_click);
            // 
            // A2
            // 
            this.A2.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.A2.Location = new System.Drawing.Point(259, 21);
            this.A2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(198, 164);
            this.A2.TabIndex = 1;
            this.A2.Tag = "1";
            this.A2.UseVisualStyleBackColor = true;
            this.A2.Click += new System.EventHandler(this.button_click);
            // 
            // A1
            // 
            this.A1.Font = new System.Drawing.Font("Tahoma", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.A1.Location = new System.Drawing.Point(28, 21);
            this.A1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(198, 164);
            this.A1.TabIndex = 0;
            this.A1.Tag = "0";
            this.A1.UseVisualStyleBackColor = true;
            this.A1.Click += new System.EventHandler(this.button_click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.player_o);
            this.panel2.Controls.Add(this.player_x);
            this.panel2.Controls.Add(this.egaluri);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.o_castiga);
            this.panel2.Controls.Add(this.x_castiga);
            this.panel2.Location = new System.Drawing.Point(750, 45);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(446, 328);
            this.panel2.TabIndex = 2;
            // 
            // egaluri
            // 
            this.egaluri.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.egaluri.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.egaluri.Location = new System.Drawing.Point(161, 249);
            this.egaluri.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.egaluri.Name = "egaluri";
            this.egaluri.Size = new System.Drawing.Size(120, 65);
            this.egaluri.TabIndex = 9;
            this.egaluri.Text = "0";
            this.egaluri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(29, 185);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(391, 60);
            this.label5.TabIndex = 8;
            this.label5.Text = "Meciuri încheiate la egalitate";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // o_castiga
            // 
            this.o_castiga.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.o_castiga.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.o_castiga.Location = new System.Drawing.Point(300, 120);
            this.o_castiga.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.o_castiga.Name = "o_castiga";
            this.o_castiga.Size = new System.Drawing.Size(120, 65);
            this.o_castiga.TabIndex = 7;
            this.o_castiga.Text = "0";
            this.o_castiga.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // x_castiga
            // 
            this.x_castiga.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.x_castiga.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.x_castiga.Location = new System.Drawing.Point(300, 59);
            this.x_castiga.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.x_castiga.Name = "x_castiga";
            this.x_castiga.Size = new System.Drawing.Size(120, 65);
            this.x_castiga.TabIndex = 6;
            this.x_castiga.Text = "0";
            this.x_castiga.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.x_castiga.Click += new System.EventHandler(this.x_castiga_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Location = new System.Drawing.Point(750, 370);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(446, 293);
            this.panel3.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(29, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(391, 116);
            this.button2.TabIndex = 5;
            this.button2.Text = "Reseteaza scorul";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(29, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(391, 127);
            this.button1.TabIndex = 4;
            this.button1.Text = "Rush Mode";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // player_x
            // 
            this.player_x.Location = new System.Drawing.Point(29, 73);
            this.player_x.Name = "player_x";
            this.player_x.Size = new System.Drawing.Size(225, 31);
            this.player_x.TabIndex = 10;
            this.player_x.Text = "Jucatorul \"X\"";
            this.player_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // player_o
            // 
            this.player_o.Location = new System.Drawing.Point(29, 131);
            this.player_o.Name = "player_o";
            this.player_o.Size = new System.Drawing.Size(225, 31);
            this.player_o.TabIndex = 11;
            this.player_o.Text = "Jucatorul \"0\"";
            this.player_o.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 685);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "X si 0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optiuniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jocNouToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iesireToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instructiuniToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Label egaluri;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label o_castiga;
        private System.Windows.Forms.Label x_castiga;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox player_o;
        private System.Windows.Forms.TextBox player_x;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}

